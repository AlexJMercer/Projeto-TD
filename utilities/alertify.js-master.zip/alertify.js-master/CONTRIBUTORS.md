# Contributors
Credit where credit is due

## Code Contributors

**Fabien Doiron**
* GitHub: [fabien-d](http://github.com/fabien-d)
* Twitter: [@fabien_doiron](http://twitter.com/fabien_doiron)
* Email: fabien.doiron@gmail.com

***

**Dan Panzarella**
* GitHub: [pzl](http://github.com/pzl)

***

**Antoine Corcy**
* GitHub: [toin0u](http://github.com/toin0u)
* Twitter: [@toin0u](https://twitter.com/toin0u)
* Email: contact@sbin.dk

***

**Stuart Keith**
* GitHub: [stuartkeith](http://github.com/stuartkeith)

***

**Dylan Anderson**
* GitHub: [quasipickle](http://github.com/quasipickle)

***

**İsmail Demirbilek**
* GitHub: [dbtek](https://github.com/dbtek)
* Website: [ismaildemirbilek.com](http://ismaildemirbilek.com/)

**Brad Berger**
* GitHub: [bradberger](http://github.com/bradberger)
* Twitter: [@berger_brad](https://twitter.com/berger_brad)
* Email: brad@bradb.net

**Dennis Heckman**
* GitHub: [denheck](https://github.com/denheck)
* Email: denheck@gmail.com

**Mehdi Lefebvre**
* GitHub: [ollie314](https://github.com/ollie314)
* Email: mehdi.lefebvre@gmail.com

**Stu Kabakoff**
* GitHub: [sakabako](https://github.com/sakabako)
* Email: sakabako@gmail.com

## Documentation Contributors

**Kristoffer Berdal**
* GitHub: [flexd](http://github.com/flexd)

***

**Michael Dabydeen**
* GitHub: [mdabydeen](http://github.com/mdabydeen)
