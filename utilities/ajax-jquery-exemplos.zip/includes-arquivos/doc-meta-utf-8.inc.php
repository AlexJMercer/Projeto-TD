<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" lang="pt-br" xml:lang="pt-br">
<head>
<title>Livro do Maujor | AJAX com jQuery</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="Site de apoio ao livro AJAX com jQuery escrito pelo Maujor (Maurício Samy Silva) no ano de 2009." />
<meta name="keywords" content="javascript, ajax, jquery, web standards, padrões web, maujor, livro do maujor" />
<meta name="author" content="Mauricio Samy Silva" />
<meta name="robots" content="all" />
<meta http-equiv="content-language" content="pt-br" />
