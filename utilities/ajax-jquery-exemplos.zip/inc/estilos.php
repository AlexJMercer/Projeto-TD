<style type="text/css" media="screen">
@import url("estilos/main.css");
</style>
<!--[if lte IE 6]>
<link rel="stylesheet" type="text/css" media="screen" href="estilos/ie6-hacks.css" />
<![endif]-->
