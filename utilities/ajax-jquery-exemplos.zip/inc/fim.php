<div id="rodape">
<p><a href="http://validator.w3.org/check?uri=referer" class="hidden"><img src= "../imagens/vxhtml.gif" alt="XHTML 1.0 Transitional V�lido" width="88" height="31"  /></a><a href="http://jigsaw.w3.org/css-validator/validator?uri=http://www.livrojquery.com.br/index.php"><img src="../imagens/vcss.gif" alt="CSS V�lida!" width="88" height="31"  /></a><small style="margin-left:350px;">�ltima modifica��o: <?php echo gmdate('Y/m/j H:i:s', filemtime($_SERVER["SCRIPT_FILENAME"])) ?> GMT</small></p> 

</div>
<div id="livro-layout"></div>
</div><!-- Fim da div#tudo -->
