﻿[	
	{
		"nome": "Amaury Júnior",
		"email": "aj@maujor.com"
	}, 

	{
		"nome": "Álvaro Monteiro Frias",
		"email": "a.monteiro@gmail.com"
	}, 

	{
		"nome": "Carlos Lima da Silva",
		"email": "cml_1972@hotmail.com"
	}, 

	{
		"nome": "Dário Senna Coutinho",
		"email": "dario@maujor.com"
	}, 

	{
		"nome": "Daniela Moutinho Silva",
		"email": "dani.mouta@yahoo.com.br"
	}, 

	{
		"nome": "Isabel Medeiros",
		"email": "isa_bel@visiva.com.br"
	}, 

	{
		"nome": "José Alexandre Junqueira",
		"email": "alex.junqueira@gmail.com"
	}, 

	{
		"nome": "Lauro Siveira",
		"email": "laurinho_sil@hotmail.com"
	}, 

	{
		"nome": "Maurício Samy Silva",
		"email": "maujorss@maujor.com"
	}, 

	{
		"nome": "Nilton Rocha Santos",
		"email": "nilton.rocha@yahoo.com.br"
	}, 

	{
		"nome": "Osmar Santos",
		"email": "o.santos@santos.com.br"
	}, 

	{
		"nome": "Pedro Paulo Guio",
		"email": "ppg@gmail.com"
	}  
]