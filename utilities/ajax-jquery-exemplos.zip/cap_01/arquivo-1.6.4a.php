<?php include("../includes-arquivos/doc-meta.inc.php"); ?>
<link href="../estilos.css" rel="stylesheet" type="text/css" />
<script type="text/javascript" src="ajaxjson.js"></script>
</head>
<body>
<div id="tudo">
<div id="conteudo">
<h1>Exemplo de requisi&ccedil;&atilde;o JSON</h1>
<a href="requisicao-json.js" onclick="requisitar(this.href); return false;">Requisitar o arquivo requisicao-json.js</a>

<div id="insere_aqui"></div>

<div id="nav">Arquivos exemplo do livro do Maujor | AJAX com jQuery: <a href="arquivo-1.6.3a.php">&laquo; anterior</a> | <a href="arquivo-1.6.5a.php">pr&oacute;ximo &raquo;</a></div>

</div>
</div>
</body>
</html>
