﻿<h2>Categoria Programa&ccedil;&atilde;o</h2>
<div class="modulo m1"> <img src="imagens/programacao/java.gif" alt=" " class="imagem" />
    <dl>
      <dt><a href="http://www.novatec.com.br/livros/javaoo"> Programa&ccedil;&atilde;o Java com Ênfase em Orienta&ccedil;&atilde;o a Objetos</a></dt>
      <dd>Autor: Douglas Rocha Mendes</dd>
      <dd>Ano: 2009</dd>
      <dd>P&aacute;ginas: 456</dd>
      <dd>Pre&ccedil;o: R$ 78,00</dd>
      <dd><a href="#"><img src="imagens/botao-comprar.gif" alt="Bot&atilde;o comprar" /></a></dd> 
    </dl>
</div>

<div class="modulo m2"> <img src="imagens/programacao/regexp.gif" alt=" " class="imagem" />
    <dl>
      <dt><a href="http://www.novatec.com.br/livros/expreg2">Express&otilde;es Regulares 2ª edi&ccedil;&atilde;o</a></dt>
      <dd>Autor: Aur&eacute;lio Marinho Jargas</dd>
      <dd>Ano: 2008</dd>
      <dd>P&aacute;ginas: 168</dd>
      <dd>Pre&ccedil;o: R$ 37,00</dd>
      <dd><a href="#"><img src="imagens/botao-comprar.gif" alt="Bot&atilde;o comprar" /></a></dd>
	</dl>
</div>

<hr />

<div class="modulo m1"><img src="imagens/programacao/jquery.gif"  alt=" " class="imagem" />
    <dl>
      <dt><a href="http://www.novatec.com.br/livros/jquery">jQuery - A Biblioteca do Programador JavaScript </a></dt>
      <dd>Autor: Maur&iacute;cio Samy Silva </dd>
      <dd>Ano: 2008</dd>
      <dd>P&aacute;ginas: 432</dd>
      <dd>Pre&ccedil;o: R$ 75,00</dd>
	  <dd><a href="#"><img src="imagens/botao-comprar.gif" alt="Bot&atilde;o comprar" /></a></dd>
    </dl>
</div>

<div class="modulo m2">
    <img src="imagens/programacao/shell.gif" alt=" " class="imagem" />
    <dl>
      <dt><a href="http://www.novatec.com.br/livros/shellscript">Shell Script Profissional</a></dt>
      <dd>Autor: Aur&eacute;lio Marinho Jargas</dd>
      <dd>Ano: 2008</dd>
      <dd>P&aacute;ginas: 480</dd>
      <dd>Pre&ccedil;o: R$ 85,00</dd>
	  <dd><a href="#"><img src="imagens/botao-comprar.gif" alt="Bot&atilde;o comprar" /></a></dd>
    </dl>
</div>

<hr />
