﻿<h2>Categoria Banco de dados</h2>
<div class="modulo m1"> <img src="imagens/banco-dados/mysql.gif" alt=" " class="imagem" />
    <dl>
      <dt><a href="http://www.novatec.com.br/livros/mysqlcompleto">MySQL - Guia do Programador</a></dt>
      <dd>Autor: Andr&eacute; Milani</dd>
      <dd>Ano: 2007</dd>
      <dd>P&aacute;ginas: 400</dd>
      <dd>Pre&ccedil;o: R$ 74,00</dd>
      <dd><a href="#"><img src="imagens/botao-comprar.gif" alt="Bot&atilde;o comprar" /></a></dd> 
    </dl>
</div>

<div class="modulo m2"> <img src="imagens/banco-dados/oracle.gif" alt=" " class="imagem" />
    <dl>
      <dt><a href="http://www.novatec.com.br/livros/oracle10g">Oracle 10g Database</a></dt>
      <dd>Autor: Roberto Rubinstein Serson</dd>
      <dd>Ano: 2004</dd>
      <dd>P&aacute;ginas: 272</dd>
      <dd>Pre&ccedil;o: R$ 59,00</dd>
      <dd><a href="#"><img src="imagens/botao-comprar.gif" alt="Bot&atilde;o comprar" /></a></dd>
	</dl>
</div>

<hr />

<div class="modulo m1"><img src="imagens/banco-dados/postgresql.gif"  alt=" " class="imagem" />
    <dl>
      <dt><a href="http://www.novatec.com.br/livros/postgre">PostgreSQL - Guia do Programador</a></dt>
      <dd>Autor: Andr&eacute; Milani</dd>
      <dd>Ano: 2008</dd>
      <dd>P&aacute;ginas: 392</dd>
      <dd>Pre&ccedil;o: R$ 72,00</dd>
	  <dd><a href="#"><img src="imagens/botao-comprar.gif" alt="Bot&atilde;o comprar" /></a></dd>
    </dl>
</div>

<div class="modulo m2">
    <img src="imagens/banco-dados/sql.gif" alt=" " class="imagem" />
    <dl>
      <dt><a href="http://www.novatec.com.br/livros/sqlcursopratico">SQL - Curso Pr&aacute;tico</a></dt>
      <dd>Autor: Celso Henrique Poderoso de Oliveira</dd>
      <dd>Ano: 2002</dd>
      <dd>P&aacute;ginas: 272</dd>
      <dd>Pre&ccedil;o: R$ 42,00</dd>
	  <dd><a href="#"><img src="imagens/botao-comprar.gif" alt="Bot&atilde;o comprar" /></a></dd>
    </dl>
</div>

<hr />
