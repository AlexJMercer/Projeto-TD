﻿<h2>Categoria Internet</h2>
<div class="modulo m1"> <img src="imagens/internet/html.gif" alt=" " class="imagem" />
    <dl>
      <dt><a href="http://www.novatec.com.br/livros/siteshtml">Criando Sites com HTML</a></dt>
      <dd>Autor: Maur&iacute;cio Samy Silva</dd>
      <dd>Ano: 2008</dd>
      <dd>P&aacute;ginas: 432</dd>
      <dd>Pre&ccedil;o: R$ 75,00</dd>
      <dd><a href="#"><img src="imagens/botao-comprar.gif" alt="Bot&atilde;o comprar" /></a></dd> 
    </dl>
</div>

<div class="modulo m2"> <img src="imagens/internet/css.gif" alt=" " class="imagem" />
    <dl>
      <dt><a href="http://www.novatec.com.br/livros/csshtml">Construindo Sites com CSS e (X)HTML</a></dt>
      <dd>Autor: Maur&iacute;cio Samy Silva</dd>
      <dd>Ano: 2008</dd>
      <dd>P&aacute;ginas: 448</dd>
      <dd>Pre&ccedil;o: R$ 75,00</dd>
      <dd><a href="#"><img src="imagens/botao-comprar.gif" alt="Bot&atilde;o comprar" /></a></dd>
	</dl>
</div>

<hr />

<div class="modulo m1"><img src="imagens/internet/google.gif"  alt=" " class="imagem" />
    <dl>
      <dt><a href="http://www.novatec.com.br/livros/googlemark">Google Marketing - O Guia Definitivo de Marketing Digital</a></dt>
      <dd>Autor: Conrado Adolpho Vaz</dd>
      <dd>Ano: 2008</dd>
      <dd>P&aacute;ginas: 480</dd>
      <dd>Pre&ccedil;o: R$ 85,00</dd>
	  <dd><a href="#"><img src="imagens/botao-comprar.gif" alt="Bot&atilde;o comprar" /></a></dd>
    </dl>
</div>

<div class="modulo m2">
    <img src="imagens/internet/php.gif" alt=" " class="imagem" />
    <dl>
      <dt><a href="http://www.novatec.com.br/livros/phppqc3">PHP para quem conhece PHP – 3ª edi&ccedil;&atilde;o</a></dt>
      <dd>Autor: Juliano Niederauer</dd>
      <dd>Ano: 2008</dd>
      <dd>P&aacute;ginas: 528</dd>
      <dd>Pre&ccedil;o: R$ 85,00</dd>
	  <dd><a href="#"><img src="imagens/botao-comprar.gif" alt="Bot&atilde;o comprar" /></a></dd>
    </dl>
</div>

<hr />

<div class="modulo m1"><img src="imagens/internet/ajaxphp.gif"  alt=" " class="imagem" />
    <dl>
      <dt><a href="http://www.novatec.com.br/livros/ajax">Web Interativa com Ajax e PHP</a></dt>
      <dd>Autor: Juliano Niederauer</dd>
      <dd>Ano: 2007</dd>
      <dd>P&aacute;ginas: 288</dd>
      <dd>Pre&ccedil;o: R$ 62,00</dd>
	  <dd><a href="#"><img src="imagens/botao-comprar.gif" alt="Bot&atilde;o comprar" /></a></dd>
    </dl>
</div>

<div class="modulo m2">
    <img src="imagens/internet/phpgtk.gif" alt=" " class="imagem" />
    <dl>
      <dt><a href="http://www.novatec.com.br/livros/phpgtk">PHP-GTK - 2ª Edi&ccedil;&atilde;o</a></dt>
      <dd>Autor: Pablo Dall’Oglio</dd>
      <dd>Ano: 2008</dd>
      <dd>P&aacute;ginas: 445</dd>
      <dd>Pre&ccedil;o: R$ 75,00</dd>
	  <dd><a href="#"><img src="imagens/botao-comprar.gif" alt="Bot&atilde;o comprar" /></a></dd>
    </dl>
</div>

<hr />







