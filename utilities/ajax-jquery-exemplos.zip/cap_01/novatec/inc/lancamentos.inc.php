<h2>Categoria Lan&ccedil;amentos</h2>
<div class="modulo m1">
<img src="imagens/lancamentos/jquerymain.jpg" alt=" " class="imagem" />
<p><strong>jQuery - A Biblioteca do Programador JavaScript</strong> - jQuery &eacute; uma poderosa biblioteca JavaScript criada para simplificar a cria&ccedil;&atilde;o de efeitos visuais e de interatividade em websites. Desenvolvedores especialistas em JavaScript, ao conhecerem as maravilhas de que a biblioteca &eacute; capaz...<a href="http://www.novatec.com.br/livros/jquery">mais</a> <img src="imagens/lancamentos/pdf_mini.gif" alt=" " /> <a href="http://www.novatec.com.br/livros/jquery/capitulo9788575221785.pdf"> Cap&iacute;tulo on-line</a></p>
</div>

<div class="modulo m2">
<img src="imagens/lancamentos/gimpmain.gif" alt=" " class="imagem" />
<p><strong>GIMP - Guia do Usu&aacute;rio 2� edi&ccedil;&atilde;o</strong> - Tratamento de imagens &eacute; uma t&eacute;cnica cada vez mais utilizada para real&ccedil;ar as principais caracter&iacute;sticas de uma imagem. Na cria&ccedil;&atilde;o de banners, folders, sites de Internet, e diversos outros meios, a qualidade gr&aacute;fica &eacute; muito importante para atrair a aten&ccedil;&atilde;o do p&uacute;blico alvo, motivo este que leva profissionais de diversas...<a href="http://www.novatec.com.br/livros/gimp">mais</a> <img src="imagens/lancamentos/pdf_mini.gif" alt=" " /> <a href="http://www.novatec.com.br/livros/gimp/capitulo9788575221716.pdf"> Cap&iacute;tulo on-line</a></p>
</div>

<hr />

<div class="modulo m1">
<p><img src="imagens/lancamentos/javaoo.jpg"  alt=" " class="imagem" /><strong>Programa&ccedil;&atilde;o Java com �nfase em Orienta&ccedil;&atilde;o a Objetos</strong> - Apresenta os principais conceitos do paradigma da orienta&ccedil;&atilde;o a objetos de forma did&aacute;tica, clara e objetiva, com base na experi�ncia do autor com projetos reais. As explica&ccedil;&otilde;es combinam teoria, exemplos e ilustra&ccedil;&otilde;es que facilitam a compreens&atilde;o dos assuntos e fornecem um caminho seguro para que o leitor incorpore o conceito de orienta&ccedil;&atilde;o a objetos em seu dia-a-dia...<a href="http://www.novatec.com.br/livros/javaoo">mais</a></p>
</div>

<div class="modulo m2">
<p><img src="imagens/lancamentos/linuxguia.gif" alt=" " class="imagem" /><strong>Linux � Guia do Administrador do Sistema - 2� Edi&ccedil;&atilde;o</strong> - Este livro &eacute; uma refer�ncia completa do Linux, abrangendo desde as atividades b&aacute;sicas de administra&ccedil;&atilde;o at&eacute; a cria&ccedil;&atilde;o e manuten&ccedil;&atilde;o de redes Linux. Destina-se tanto a usu&aacute;rios iniciantes na administra&ccedil;&atilde;o de sistemas Linux, como aos mais experientes que desejam projetar e administrar suas pr&oacute;prias redes Linux...<a href="http://www.novatec.com.br/livros/linuxguiaadm2">mais</a> <img src="imagens/lancamentos/pdf_mini.gif" alt=" " /> <a href="http://www.novatec.com.br/livros/linuxguiaadm2/capitulo9788575221778.pdf"> Cap&iacute;tulo on-line</a></p>
</div>

<hr />

<div class="modulo m1">
<p><img src="imagens/lancamentos/iphone.jpg"  alt=" " class="imagem" /><strong>Domine seu iPhone</strong> - O iPhone est&aacute; sendo considerado a maior inven&ccedil;&atilde;o tecnol&oacute;gica dos &uacute;ltimos tempos. Desde seu an&uacute;ncio, n&atilde;o p&aacute;ra de encantar as pessoas. Os usu&aacute;rios deparam-se com um verdadeiro arsenal de recursos e programas que o tornam muito mais que um simples telefone, como tamb&eacute;m uma ferramenta indispens&aacute;vel para as atividades do dia a dia...<a href="http://www.novatec.com.br/livros/iphone">mais</a></p>
</div>

<div class="modulo m2">
<p><img src="imagens/lancamentos/avaliando.jpg" alt=" " class="imagem" /><strong>Avaliando Empresas, Investindo em A&ccedil;&otilde;es</strong> - Avaliando Empresas, Investindo em A&ccedil;&otilde;es &eacute; uma obra destinada a investidores que desejam conhecer, em detalhes, os m&eacute;todos de an&aacute;lise que integram a linha de trabalho da escola fundamentalista, trazendo ao leitor, em linguagem clara e acess&iacute;vel, o conhecimento profundo dos elementos necess&aacute;rios...<a href="http://www.novatec.com.br/livros/avaliando_emp">mais</a> <img src="imagens/lancamentos/pdf_mini.gif" alt=" " /> <a href="http://www.novatec.com.br/livros/avaliando_emp/capitulo9788575221792.pdf"> Cap&iacute;tulo on-line</a></p>
</div>

<hr />




